/**
 * @author Carly Rolfes
 * Example of a multiplication table generator created for the use of  
 * Girl Scout troops in pursuit of the GRILL Scout Introductory Patch
 * 
 * This is NOT the only way to complete this project. There are always many
 * ways to go about a solution. Not everyone has the same thought process, so
 * not everyone will come up with the same solution.
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        /*This program accounts for results up to 3 digits, 
        so dim should only be up to 32*/
        int dim = 32;
        
        for (int i = 1; i <= dim; i ++){
            for(int j = 1; j <= dim; j++){
                
                int mult = i*j;
                
                if(mult < 10){
                    System.out.print(mult + "    ");
                }
                else if(mult < 100){
                    System.out.print(mult + "   ");
                }
                else {
                    System.out.print(mult + "  ");
                }
                
            }
            System.out.println("\n");
        }
    }
    
}
