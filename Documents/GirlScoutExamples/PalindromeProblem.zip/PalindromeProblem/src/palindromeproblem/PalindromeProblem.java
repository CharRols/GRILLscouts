/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package palindromeproblem;

import java.util.Scanner;

/**
 *
 * @author Carly
 */
public class PalindromeProblem {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       //Allows for input from the keyboard - requires import java.util.Scanner
        //The word keyboard here is a variable name. You use anything you want,
        //but it is best to keep it short and relevant.
        Scanner keyboard = new Scanner(System.in);
        
        //Tells the program to translate another word
        boolean keepGoing = true;
        
        //This loop will go until the user decides that they don't want to 
        //translate any more words (when keepGoing is set to false)
        while(keepGoing){ 
            //Prints the quoted string to the console followed by a new line
            System.out.println("What word do you want to check?");   
        
            /** check(keyboard.nextLine()) is a function call. It calls the
            function check and passes it the string that the user inputs.
            keyboard.nextLine() accepts user input until they hit Enter. 
            By putting the keyboard call in the function call, the program 
            is more efficient and uses fewer variables.*/
            check(keyboard.nextLine());
            
            
            //The while loop will go until the user either enters "yes" or "no"
            //it ignores the case of the letters, so "Yes" and "nO" are also
            //acceptable input.
            boolean input = true;
            while(input){
                System.out.println("Do you want to translate another word? "
                        + "Yes or no?");
                String cont = keyboard.nextLine();
                
                if(cont.equalsIgnoreCase("no")){
                    keepGoing = false;
                    input = false;
                }else if (cont.equalsIgnoreCase("yes")){
                    input = false;
                }//end else if block
            }//end while input loop
            
        }//end while keepGoing loop
        
        
    }//end main
    
    /*Fill in the blanks so that this method checks if userInput is a 
    palindrome or not.*/
    public static void check(String userInput){
        //output the input word
        System.out.println("Your input: " + userInput);
        
        //We are using a char array to put the string in reverse so that we can
        //build it character by character
        char[] checkArray = new char[userInput.length()];
        
        //this loop puts the reverse of userInput into checkArray
        int j = userInput.length() - 1;
        for(int i = 0; i < userInput.length(); i++){
            checkArray[j] = ;
            j ;
        }
        
        //convert checkArray to a String and print it
        String backwards = new String();
        System.out.println("Backwards: " + backwards);
        
        //If the input is a palindrome, it will be the same backwards as it is
        //forwards and the variable palindrome will be true.
        boolean palindrome = backwards. ();
        
        //output results
        if(palindrome){
            System.out.println("Your input is a palindrome");
        }
        else{
            System.out.println("Your input is not a palindrome");
        }
    }//end Check function  
}//end