package fortunecookie;

/**
 * @author Carly Rolfes
 * Example of an English to fortune teller created for the use of Ambassador
 * level Girl Scout troops in pursuit of the GRILL Scout Introductory Patch
 * 
 * This is NOT the only way to complete this project. There are always many
 * ways to go about a solution. Not everyone has the same thought process, so
 * not everyone will come up with the same solution.
 */
public class FortuneCookie {

    /**
     * @param args the command line arguments - comes with the automatically 
     * generated main method. We will not be using this for anything, so leave
     * it be.
     */
    
    //The main method is where the program starts
    public static void main(String[] args) {
        int num = (int)(Math.random() * 100) + 1;
        
        System.out.print("Your fortune is: ");
        System.out.print((num % 2 == 0) ? "You will " : "You will not ");
        
        num = (int)(Math.random() * 6) + 1;
        if(num == 1){
            System.out.println("start your own business");
        } else if(num == 2){
            System.out.println("die rich");
        }else{
            /*The switch is inside the else, because otherwise if the number is
            less than 3 the default will be executed*/
            switch (num){
                case 3: System.out.println("get married young");
                    break;
                case 4: System.out.println("find true love");
                    break;
                case 5: System.out.println("be very successful");
                    break;
                case 6: System.out.println("work in a career you enjoy");
                    break;
                default: System.out.println("ERROR");
            }
        }
    }
    
}
