/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package multiplicationtableproblem;

/**
 *
 * @author Carly
 */
public class MultiplicationTableProblem {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        /*This program accounts for results up to 3 digits, 
        so dim should only be up to 32*/
        int dim = 32;
        
        /*Fill in the blanks in the code*/
        
        for (){
            for(){
                
                int mult = ;
                
                if(mult < 10){
                    System.out.print(mult + "    ");
                }
                else if(mult < 100){
                    System.out.print(mult + "   ");
                }
                else {
                    System.out.print(mult + "  ");
                }
                
            }
            System.out.println("\n");
        }
    }
    
}
