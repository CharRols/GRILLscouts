package isitatriangle;

/**   
 * @author Carly Rolfes
 * Example of a triangle checker created for the used of Senior level Girl
 * Scout troops in pursuit of the GRILL Scout Introductory Patch
 * 
 * This is NOT the only way to complete this project. There are always many
 * ways to go about a solution. Not everyone has the same thought process, so
 * not everyone will come up with the same solution.
 */
public class IsItATriangle {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //the sum of the lengths of any two sides of a triangle must be 
        //greater than or equal to the length of the third side.
        int sideA = 4;
        int sideB = 9;
        int sideC = 6;
        
        int sumAB = sideA + sideB;
        int sumAC = sideA + sideC;
        int sumBC = sideB + sideC;
        
        if(sumAB < sideC || sumAC < sideB || sumBC < sideA){
            System.out.println("This cannot be a triangle");
        }else{
            System.out.println("This is a triangle");
        }
    }
    
}
