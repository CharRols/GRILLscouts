package evenorodd;

/**   
 * @author Carly Rolfes
 * Example of an even or odd number checker created for the used of Senior level 
 * Girl Scout troops in pursuit of the GRILL Scout Introductory Patch
 * 
 * This is NOT the only way to complete this project. There are always many
 * ways to go about a solution. Not everyone has the same thought process, so
 * not everyone will come up with the same solution.
 */
public class EvenOrOdd {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Set num equal to the number you want to test
        int num = 58562;
        //rem is the result of num modulo 2
        int rem = num % 2;
        
        //if num modulo 2 results in a zero, the number is even
        if(rem == 0){
            System.out.println("The number " + num + " is even");
        }else{
            System.out.println("The number " + num + " is odd");
        }
    }
    
}
