//This import is needed to allow for user input from the keyboard
import java.util.Scanner;

/**
 * @author Carly Rolfes
 * Example of an English to Pig Latin translator created for the use of Girl 
 * Scout troops in pursuit of the GRILL Scout Introductory Patch
 * 
 * This example is more advanced than what is covered in the patch program
 * 
 * This is NOT the only way to complete this project. There are always many
 * ways to go about a solution. Not everyone has the same thought process, so
 * not everyone will come up with the same solution.
 */
public class Main {

    /**
     * This program allows the user to input a word and then it will output that
     * word in Pig Latin. It will go until the users tells it to stop.
     * 
     * Each method (or function, whatever you prefer) should have a block of
     * comments like this telling what it does, if it returns any values, and
     * what parameters (@param) that are being passed to it.
     * 
     * @param args the command line arguments - comes with the automatically 
     * generated main method. We will not be using this for anything, so leave 
     * it be.
     */
    
    //The main method is where the program starts
    public static void main(String[] args) {
        //Allows for input from the keyboard - requires import java.util.Scanner
        //The word keyboard here is a variable name. You use anything you want,
        //but it is best to keep it short and relevant.
        Scanner keyboard = new Scanner(System.in);
        
        //Tells the program to translate another word
        boolean keepGoing = true;
        
        //This loop will go until the user decides that they don't want to 
        //translate any more words (when keepGoing is set to false)
        while(keepGoing){ 
            //Prints the quoted string to the console followed by a new line
            System.out.println("What word do you want to translate?");            
            
            /** Translate(keyboard.nextLine()) is a function call. It calls the
            function Translate and passes it the string that the user inputs.
            The string that it returns is immediately printed to the console.
            keyboard.nextLine() accepts user input until they hit Enter. 
            By putting the keyboard call in the function call and the function
            call in the print statement, the program is more efficient and
            uses fewer variables.*/
            System.out.println(Translate(keyboard.nextLine()));
            
            //The while loop will go until the user either enters "yes" or "no"
            //it ignores the case of the letters, so "Yes" and "nO" are also
            //acceptable input.
            boolean input = true;
            while(input){
                System.out.println("Do you want to translate another word? "
                        + "Yes or no?");
                String cont = keyboard.nextLine();
                
                if(cont.equalsIgnoreCase("no")){
                    keepGoing = false;
                    input = false;
                }else if (cont.equalsIgnoreCase("yes")){
                    input = false;
                }//end else if block
            }//end while input loop
        }//end while keep going loop    
    }//end main method
    
    
    /**
     * This function takes a String of letters and outputs them according to
     * the rules of Pig Latin
     * 
     * @param word - the word to be translated
     * @return a String that contains the translated word
     */
    public static String Translate(String word){
       
        /** Because whatever is returned from this function get printed 
         immediately, this statement needs to be here so that it is printed 
         after getting user input but before the translation is output.
         Notice this uses print instead of println so there will be no new 
         line after this statement. */
        System.out.print("Tanslated into Pig Latin: ");
        
        //This string is used to determine if the first letter of the word 
        //is a vowel
        String vowels = "aeiou";
        
        //By converting the word to all lowercase, it makes checking for a
        //vowel easier since the vowel string is all lowercase
        word = word.toLowerCase();
        
        /** This is where the actual translation happens
         word.substring(0, 1) returns a String that contains only the first
         letter of the word. The function contains() requires a String as a
         parameter, so word.charAt(0) can't be used here. 
         It should be noted that all indexes start at 0, not 1 */
        if(vowels.contains(word.substring(0, 1))){
            //By returning this String value directly and not making a variable,
            //the program is more efficient.
            return word + "yay";
        }else{
            //word.substring(1) returns word without the first letter
            return word.substring(1) + word.charAt(0) + "ay";
        }
        
    }//end Translate method        
}//end class